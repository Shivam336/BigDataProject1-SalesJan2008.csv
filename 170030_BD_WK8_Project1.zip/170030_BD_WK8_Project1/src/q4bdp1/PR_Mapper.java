package q4bdp1;

/*
 * Question 4 Find out number of times each payment type is used.
 * 
 * 28-09-2019  Mapper class for finding number of times each payment type is used.
 * 
 * @author Shivam Singhal
 */

import java.io.IOException;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.LongWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.MapReduceBase;    
import org.apache.hadoop.mapred.Mapper;    
import org.apache.hadoop.mapred.OutputCollector;    
import org.apache.hadoop.mapred.Reporter;    

public class PR_Mapper extends MapReduceBase implements Mapper <LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1);

	public void map(LongWritable key, Text value, OutputCollector <Text, IntWritable> output, Reporter reporter) throws IOException {

		String line = value.toString();
		String[] PaymentTypeUsedData = line.split(",");				//In csv file each column is separated by ","
		output.collect(new Text(PaymentTypeUsedData[1]), one);		//Here 1 is the index of column of type of product in csv file
	}
}