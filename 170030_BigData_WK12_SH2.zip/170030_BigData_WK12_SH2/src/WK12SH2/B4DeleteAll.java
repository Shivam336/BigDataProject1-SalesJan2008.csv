package WK12SH2;

/**
 * 
 * Data Manipulation Language 
 * 
 * 4. Deleteall command
 * 
 * @author Shivam 
 */


import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.util.Bytes;


public class B4DeleteAll {
	
	public static void main(String[] args) throws IOException {
		
		Configuration conf = new Configuration();
		HBaseAdmin admin= new HBaseAdmin(conf);
		HTable table=new HTable(conf, Bytes.toBytes("vehicles"));
		admin.disableTable(Bytes.toBytes("vehicles"));
		Delete del=new Delete(Bytes.toBytes("r1"));
		table.delete(del);
		System.out.println("Row 1 is deleted");
		
	}

}
