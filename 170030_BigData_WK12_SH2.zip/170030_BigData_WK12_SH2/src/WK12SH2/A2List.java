package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 2. List a table command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class A2List {
	
	public static void main (String args[]) throws MasterNotRunningException, ZooKeeperConnectionException, IOException{

    Configuration conf = HBaseConfiguration.create();
    HBaseAdmin admin = new HBaseAdmin(conf);
    HTableDescriptor[] tableDes=admin.listTables();
    
    for(HTableDescriptor ls:tableDes){
    	System.out.println(ls);
    }
}
}