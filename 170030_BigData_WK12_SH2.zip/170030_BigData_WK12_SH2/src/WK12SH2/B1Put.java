package WK12SH2;

/**
 * 
 * Data Manipulation Language 
 * 
 * 1. Put command
 * 
 * @author Shivam 
 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class B1Put{

   public static void main(String[] args) throws IOException {

      // instantiate Configuration class
      Configuration config = HBaseConfiguration.create();

      // instantiate HTable class
      HTable hTable = new HTable(config, "vehicles");

      // instantiate Put class
      Put r1 = new Put(Bytes.toBytes("r1"));
      Put r2 = new Put(Bytes.toBytes("r2")); 
      Put r3 = new Put(Bytes.toBytes("r3")); 
      Put r4 = new Put(Bytes.toBytes("r4")); 
      Put r5 = new Put(Bytes.toBytes("r5")); 

      // add values using add() method
      r1.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCompany"),Bytes.toBytes("Maruti"));
      r1.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarName"),Bytes.toBytes("Breeza"));
      r1.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCost"),Bytes.toBytes("1000000"));
      
      r2.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCompany"),Bytes.toBytes("Hyundai"));
      r2.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarName"),Bytes.toBytes("I20"));
      r2.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCost"),Bytes.toBytes("2000000"));
      
      r3.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCompany"),Bytes.toBytes("Toyota"));
      r3.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarName"),Bytes.toBytes("Innova"));
      r3.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCost"),Bytes.toBytes("3000000"));
      
      r4.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCompany"),Bytes.toBytes("Renault"));
      r4.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarName"),Bytes.toBytes("Duster"));
      r4.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCost"),Bytes.toBytes("4000000"));
      
      r5.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCompany"),Bytes.toBytes("Honda"));
      r5.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarName"),Bytes.toBytes("Civic"));
      r5.add(Bytes.toBytes("car"),
		Bytes.toBytes("CarCost"),Bytes.toBytes("5000000"));
      
      
      r1.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCompany"),Bytes.toBytes("Hero"));
      r1.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeName"),Bytes.toBytes("Ignitor"));
      r1.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCost"),Bytes.toBytes("10000"));

      r2.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCompany"),Bytes.toBytes("Suzuki"));
      r2.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeName"),Bytes.toBytes("Gixer"));
      r2.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCost"),Bytes.toBytes("20000"));
      
      r3.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCompany"),Bytes.toBytes("Kawasaki"));
      r3.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeName"),Bytes.toBytes("Ninja"));
      r3.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCost"),Bytes.toBytes("30000"));
      
      r4.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCompany"),Bytes.toBytes("RoyalEnfield"));
      r4.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeName"),Bytes.toBytes("R2000"));
      r4.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCost"),Bytes.toBytes("40000"));
      
      r5.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCompany"),Bytes.toBytes("Bajaj"));
      r5.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeName"),Bytes.toBytes("Vikrant"));
      r5.add(Bytes.toBytes("bike"),
		Bytes.toBytes("BikeCost"),Bytes.toBytes("50000"));
      
      hTable.put(r1);
      hTable.put(r2);
      hTable.put(r3);
      hTable.put(r4);
      hTable.put(r5);

      System.out.println("Data Inserted");
      
      hTable.close();
   }
}