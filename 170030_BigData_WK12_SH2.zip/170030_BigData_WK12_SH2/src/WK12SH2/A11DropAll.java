package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 11. Drop All table command
 * 
 * @author Shivam 
 */

import java.io.IOException;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class A11DropAll {

   public static void main(String[] args) throws IOException {

      Configuration conf = HBaseConfiguration.create();
      HBaseAdmin admin = new HBaseAdmin(conf);

      admin.disableTables("veh.*");
     
      // delete table
      admin.deleteTables("veh.*");
      System.out.println("Table with regular expression veh.* are deleted");
   }
}