package q4bdp1;

/*
 * Question 4 Find out number of times each payment type is used.
 * 
 * 28-09-2019  Runner class for finding number of times each payment type is used.
 * 
 * @author Shivam Singhal
 */

import java.io.IOException;    
import org.apache.hadoop.fs.Path;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.FileInputFormat;    
import org.apache.hadoop.mapred.FileOutputFormat;    
import org.apache.hadoop.mapred.JobClient;    
import org.apache.hadoop.mapred.JobConf;    
import org.apache.hadoop.mapred.TextInputFormat;    
import org.apache.hadoop.mapred.TextOutputFormat;    
public class PR_Runner {    
    public static void main(String[] args) throws IOException{    
        JobConf conf = new JobConf(PR_Runner.class);    
        conf.setJobName("ProductSold");    
        conf.setOutputKeyClass(Text.class);    
        conf.setOutputValueClass(IntWritable.class);            
        conf.setMapperClass(PR_Mapper.class);    
        conf.setCombinerClass(PR_Reducer.class);    
        conf.setReducerClass(PR_Reducer.class);         
        conf.setInputFormat(TextInputFormat.class);    
        conf.setOutputFormat(TextOutputFormat.class);           
        FileInputFormat.setInputPaths(conf,new Path(args[0]));    
        FileOutputFormat.setOutputPath(conf,new Path(args[1]));     
        JobClient.runJob(conf);    
    }    
}  