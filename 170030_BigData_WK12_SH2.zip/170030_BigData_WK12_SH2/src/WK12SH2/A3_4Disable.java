package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 3 and 4. disable and is_disabled command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class A3_4Disable{

   public static void main(String args[]) throws MasterNotRunningException, IOException{

      Configuration conf = HBaseConfiguration.create();
      HBaseAdmin admin = new HBaseAdmin(conf);
      
      boolean isDisabled = admin.isTableDisabled(Bytes.toBytes("bikes"));

      if(!isDisabled){
         admin.disableTable(Bytes.toBytes("bikes"));
         System.out.println("Table bikes is disabled");
      }
   }
}