package HBase;

/**
*
* 7 . Truncate Command

* @author Shivam Singhal
*
**/
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class B7Truncate {
	
	public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException
	{
		Configuration config = HBaseConfiguration.create();
		HBaseAdmin admin = new HBaseAdmin(config);
		admin.disableTable(Bytes.toBytes("vehicles"));
		admin.truncateTable(Bytes.toBytes("vehicles"), true);
		admin.enableTable("vehicles");
	    		
	}

}
