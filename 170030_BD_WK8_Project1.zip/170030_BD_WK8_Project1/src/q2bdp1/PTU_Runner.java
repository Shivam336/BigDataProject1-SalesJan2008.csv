package q2bdp1;

/*
 * Question 2 Find out number of times each payment type is used.
 * 
 * 28-09-2019  Runner class for finding number of times each payment type is used.
 * 
 * @author Shivam Singhal
 */

import java.io.IOException;    
import org.apache.hadoop.fs.Path;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.FileInputFormat;    
import org.apache.hadoop.mapred.FileOutputFormat;    
import org.apache.hadoop.mapred.JobClient;    
import org.apache.hadoop.mapred.JobConf;    
import org.apache.hadoop.mapred.TextInputFormat;    
import org.apache.hadoop.mapred.TextOutputFormat;    
public class PTU_Runner {    
    public static void main(String[] args) throws IOException{    
        JobConf conf = new JobConf(PTU_Runner.class);    
        conf.setJobName("PaymentTypeUsed");    
        conf.setOutputKeyClass(Text.class);    
        conf.setOutputValueClass(IntWritable.class);            
        conf.setMapperClass(PTU_Mapper.class);    
        conf.setCombinerClass(PTU_Reducer.class);    
        conf.setReducerClass(PTU_Reducer.class);         
        conf.setInputFormat(TextInputFormat.class);    
        conf.setOutputFormat(TextOutputFormat.class);           
        FileInputFormat.setInputPaths(conf,new Path(args[0]));    
        FileOutputFormat.setOutputPath(conf,new Path(args[1]));     
        JobClient.runJob(conf);    
    }    
}  