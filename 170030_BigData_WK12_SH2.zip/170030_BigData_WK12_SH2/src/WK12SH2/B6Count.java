package WK12SH2;

/**
 * 
 * Data Manipulation Language 
 * 
 * 6. Count command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

public class B6Count {

	   public static void main(String args[]) throws IOException{

		      Configuration config = HBaseConfiguration.create();
		      HTable table = new HTable(config, "vehicles");
		      int count=0;
		      Scan scan = new Scan();

		      scan.addColumn(Bytes.toBytes("car"), Bytes.toBytes("CarCompany"));
		      scan.addColumn(Bytes.toBytes("car"), Bytes.toBytes("CarName"));
		      scan.addColumn(Bytes.toBytes("car"), Bytes.toBytes("CarCost"));
		      scan.addColumn(Bytes.toBytes("bike"), Bytes.toBytes("BikeCompany"));
		      scan.addColumn(Bytes.toBytes("bike"), Bytes.toBytes("BikeName"));
		      scan.addColumn(Bytes.toBytes("bike"), Bytes.toBytes("BikeCost"));

		      ResultScanner scanner = table.getScanner(scan);
		      for (Result result = scanner.next(); result != null; result=scanner.next())
		        count++;
		      
		      System.out.println("Total Count: "+count);

		      scanner.close();
		   }
}