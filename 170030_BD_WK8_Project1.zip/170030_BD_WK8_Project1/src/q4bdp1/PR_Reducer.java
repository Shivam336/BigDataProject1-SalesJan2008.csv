package q4bdp1;

/*
 * Question 4 Find out number of times each payment type is used.
 * 
 * 28-09-2019  Reducer class for finding number of times each payment type is used.
 * 
 * @author Shivam Singhal
 */


import java.io.IOException;
import java.util.*;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

public class PR_Reducer extends MapReduceBase implements Reducer<Text, IntWritable, Text, IntWritable> {

	public void reduce(Text t_key, Iterator<IntWritable> values, OutputCollector<Text,IntWritable> output, Reporter reporter) throws IOException {
		Text key = t_key;
		int frequencyForCountry = 0;
		Text pr=new Text("Product1");
		Text pr2=new Text("Product2");
		if(key.equals(pr) || key.equals(pr2)){
		while (values.hasNext()) {
			IntWritable value = (IntWritable) values.next();
			frequencyForCountry += value.get();
			
		}
		output.collect(key, new IntWritable(frequencyForCountry));
		}
		
		
	}
}