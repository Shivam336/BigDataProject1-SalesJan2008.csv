package bdp1;


/*
 * Question 1 Find out number of product sold in each country.
 * 
 * 28-09-2019  Mapper class for finding number of product sold in each country.
 * 
 * @author Shivam Singhal
 */


import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

public class SalesMapper extends MapReduceBase implements Mapper <LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1);

	public void map(LongWritable key, Text value, OutputCollector <Text, IntWritable> output, Reporter reporter) throws IOException {

		String country = value.toString();
		String[] countryArr = country.split(",");		//In csv file each column is separated by ","
		output.collect(new Text(countryArr[7]), one);   //Here 7 is the index of column of country in csv file
	}
}