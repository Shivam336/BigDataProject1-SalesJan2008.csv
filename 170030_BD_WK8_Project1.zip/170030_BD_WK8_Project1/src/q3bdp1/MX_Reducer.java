package q3bdp1;

/*
 * Question 3 Find out maximum times a payment type is used.
 * 
 * 28-09-2019  Reducer class for finding maximum times a payment type is used.
 * 
 * @author Shivam Singhal
 */


import java.io.IOException;    
import java.util.Iterator;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.MapReduceBase;    
import org.apache.hadoop.mapred.OutputCollector;    
import org.apache.hadoop.mapred.Reducer;    
import org.apache.hadoop.mapred.Reporter;    

public class MX_Reducer  extends MapReduceBase implements Reducer<Text,IntWritable,Text,IntWritable> {  
	public int max=0;
	int index =0;
	Text maxPaymentUsed=new Text(); 
	int length=0;
	public void reduce(Text key, Iterator<IntWritable> values,OutputCollector<Text,IntWritable> output,    
			Reporter reporter) throws IOException {    
		Text t_key=key;
		length=6;
		int sum=0;    
		while (values.hasNext()) {   
			IntWritable value = (IntWritable)values.next();
			sum+=value.get();  

		} 
		
		if(max<sum){
			max=sum;
			maxPaymentUsed.set(t_key);
			
			
		}
		index++;
		

		if(index==length){
		output.collect(new Text("Maximum Payment Used is : "+maxPaymentUsed),new IntWritable(max));  
		}
		else{
		output.collect(t_key,new IntWritable(sum));  
		}
	}    
}  