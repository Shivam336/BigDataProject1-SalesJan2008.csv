package WK12SH2;

/**
 * 
 * Data Manipulation Language
 * 
 * 2. Get Command
 * 
 * @author Shivam
 */

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

public class B2Get {
	
	public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
		
		Configuration conf=new Configuration();
		HBaseAdmin admin=new HBaseAdmin(conf);
		HTable table=new HTable(conf, Bytes.toBytes("vehicles"));
		Get value=new Get(Bytes.toBytes("r1"));
		Result re=table.get(value);
		byte[]  data1=re.getValue(Bytes.toBytes("car"), Bytes.toBytes("CarCompany"));
		String data1value=Bytes.toString(data1);
		System.out.println(data1value);
	}

}
