package WK12SH2;

/**
 * 
 * Data Manipulation Language
 * 
 * 5. Scan Command
 * 
 * @author Shivam
 */

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;

public class B5Scan{

   public static void main(String args[]) throws IOException{

      Configuration config = HBaseConfiguration.create();
      HTable table = new HTable(config, "vehicles");
      Scan scan = new Scan();

      // scan the columns
      scan.addColumn(Bytes.toBytes("car"), Bytes.toBytes("CarCompany"));
      scan.addColumn(Bytes.toBytes("car"), Bytes.toBytes("CarName"));
      scan.addColumn(Bytes.toBytes("car"), Bytes.toBytes("CarCost"));
      
      scan.addColumn(Bytes.toBytes("bike"), Bytes.toBytes("BikeCompany"));
      scan.addColumn(Bytes.toBytes("bike"), Bytes.toBytes("BikeName"));
      scan.addColumn(Bytes.toBytes("bike"), Bytes.toBytes("BikeCost"));

      // get the ResultScanner
      ResultScanner scanner = table.getScanner(scan);
      for (Result result = scanner.next(); result != null; result=scanner.next())
    	  System.out.println(result.toString());

      scanner.close();
   }
}