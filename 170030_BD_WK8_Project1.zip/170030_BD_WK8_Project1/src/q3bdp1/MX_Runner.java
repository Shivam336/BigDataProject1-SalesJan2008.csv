package q3bdp1;

/*
 * Question 3 Find out maximum times a payment type is used.
 * 
 * 28-09-2019  Runner class for finding maximum times a payment type is used.
 * 
 * @author Shivam Singhal
 */


import java.io.IOException;    
import org.apache.hadoop.fs.Path;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.FileInputFormat;    
import org.apache.hadoop.mapred.FileOutputFormat;    
import org.apache.hadoop.mapred.JobClient;    
import org.apache.hadoop.mapred.JobConf;    
import org.apache.hadoop.mapred.TextInputFormat;    
import org.apache.hadoop.mapred.TextOutputFormat;    
public class MX_Runner {    
    public static void main(String[] args) throws IOException{    
        JobConf conf = new JobConf(MX_Runner.class);    
        conf.setJobName("MaximumTimePaymentUsed");    
        conf.setOutputKeyClass(Text.class);    
        conf.setOutputValueClass(IntWritable.class);            
        conf.setMapperClass(MX_Mapper.class);    
        conf.setCombinerClass(MX_Reducer.class);    
        conf.setReducerClass(MX_Reducer.class);         
        conf.setInputFormat(TextInputFormat.class);    
        conf.setOutputFormat(TextOutputFormat.class);           
        FileInputFormat.setInputPaths(conf,new Path(args[0]));    
        FileOutputFormat.setOutputPath(conf,new Path(args[1]));     
        JobClient.runJob(conf);    
    }    
}  