package WK12SH2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HBaseAdmin;

public class A8Alter {
	
	public static void main(String[] args) {
		
		Configuration conf= new Configuration();
		HBaseAdmin admin= new HBaseAdmin(conf);
		a
	}

}
