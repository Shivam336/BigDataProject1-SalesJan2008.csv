package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 1. create command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.conf.Configuration;

public class A1Create {

	public static void main(String[] args) throws IOException {

		Configuration conf = HBaseConfiguration.create();

		// instantiating HbaseAdmin class by passing on configuration class
		HBaseAdmin admin = new HBaseAdmin(conf);

		HTableDescriptor tableDescriptor = new
				HTableDescriptor(Bytes.toBytes("vehicles"));

		// adding column families to table descriptor
		tableDescriptor.addFamily(new HColumnDescriptor(Bytes.toBytes("car")));
		tableDescriptor.addFamily(new HColumnDescriptor(Bytes.toBytes("bike")));
		
		// creating the table
		admin.createTable(tableDescriptor);
		System.out.println(" Table created ");
	}
}