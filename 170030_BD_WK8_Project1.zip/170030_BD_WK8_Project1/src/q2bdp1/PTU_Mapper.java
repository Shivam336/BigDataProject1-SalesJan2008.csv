package q2bdp1;

/*
 * Question 2 Find out number of times each payment type is used.
 * 
 * 28-09-2019  Mapper class for finding number of times each payment type is used.
 * 
 * @author Shivam Singhal
 */


import java.io.IOException;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.LongWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.MapReduceBase;    
import org.apache.hadoop.mapred.Mapper;    
import org.apache.hadoop.mapred.OutputCollector;    
import org.apache.hadoop.mapred.Reporter;    

public class PTU_Mapper extends MapReduceBase implements Mapper <LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1);

	public void map(LongWritable key, Text value, OutputCollector <Text, IntWritable> output, Reporter reporter) throws IOException {

		String line = value.toString();
		String[] PaymentTypeUsedData = line.split(","); 		 //In csv file each column is separated by ","
		output.collect(new Text(PaymentTypeUsedData[3]), one);   //Here 3 is the index of column of type of payment in csv file
	}
}