package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 5 and 6. enable and is_enabled command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class A5_6Enable{

   public static void main(String args[]) throws MasterNotRunningException, IOException{

      Configuration conf = HBaseConfiguration.create();
      HBaseAdmin admin = new HBaseAdmin(conf);
      
      boolean isEnabled = admin.isTableEnabled(Bytes.toBytes("bikes"));

      if(!isEnabled){
         admin.enableTable(Bytes.toBytes("bikes"));
         System.out.println("Table bikes is Enabled");
      }
   }
}