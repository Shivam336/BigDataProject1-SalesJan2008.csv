package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 10. Drop a table command
 * 
 * @author Shivam 
 */

import java.io.IOException;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class A10Drop {

   public static void main(String[] args) throws IOException {

      Configuration conf = HBaseConfiguration.create();
      HBaseAdmin admin = new HBaseAdmin(conf);
      admin.disableTable(Bytes.toBytes("vehicles"));
      // delete table
      admin.deleteTable(Bytes.toBytes("vehicles"));
      System.out.println("Table vehicles is deleted");
   }
}