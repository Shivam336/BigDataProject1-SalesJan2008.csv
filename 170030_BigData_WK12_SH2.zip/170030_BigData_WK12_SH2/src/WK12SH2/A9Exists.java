package WK12SH2;

/**
 * 
 * Data Definition Language 
 * 
 * 2. Exist command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class A9Exists{

   public static void main(String args[])throws IOException{

      Configuration conf = HBaseConfiguration.create();
      HBaseAdmin admin = new HBaseAdmin(conf);
      
      boolean bool = admin.tableExists(Bytes.toBytes("vehicle"));
      System.out.println("Table bikes exists: " + bool);
   }
} 