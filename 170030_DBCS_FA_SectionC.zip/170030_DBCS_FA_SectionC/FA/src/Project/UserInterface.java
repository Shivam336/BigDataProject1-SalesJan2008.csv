package Project;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


/**
 * Final Assessment of Database & Client Server
 * 
 * Description:
 * 
 * Userinterface class in which UI for this project is created.
 * 
 * @author Shivam Singhal  |   170030
 * 
 * @version 1.0  07-12-2019
 *
 */


public class UserInterface {

	public String LOCALHOST="localhost:3308";
	public String DATABASE_NAME="brainstorming";
	public String USER="root";
	public String PASSWORD="root";
	public String TABLE1_NAME="student_data";

	private Label lbl_fileName = new Label("Select File");
	public TextField txt_fileName = new TextField();
	private Button btn_browse = new Button("Browse");
	private Button btn_loadData = new Button("Load Data");
	public int loadfile1y=100;
	public int loadfile2y=150;


	private Button btn_addData = new Button("Insert");
	private Label lbl_Reg_No = new Label("Reg No.");
	public TextField txt_Reg_No = new TextField();
	private Label lbl_Roll_No = new Label("Roll No.");
	public TextField txt_Roll_No = new TextField();
	private Label lbl_Name = new Label("Name");
	public TextField txt_Name = new TextField();
	private Label lbl_Father_Name = new Label("Father Name");
	public TextField txt_Father_Name = new TextField();
	private Label lbl_Mother_Name = new Label("Mother Name");
	public TextField txt_Mother_Name = new TextField();
	private Label lbl_Course = new Label("Course");
	public TextField txt_Course = new TextField();
	private Label lbl_Semester = new Label("Semester");
	public TextField txt_Semester = new TextField();
	private Label lbl_Year = new Label("Year");
	public TextField txt_Year = new TextField();
	private Button btn_add = new Button("Insert");
	private Button btn_update = new Button("Update");

	private Button btn_modifyData = new Button("Update");
	private Label lbl_Roll_No1 = new Label("Roll No.");
	public TextField txt_Roll_No1 = new TextField();
	private Button btn_select = new Button("Open");

	private Button btn_deleteData = new Button("Delete");
	private Label lbl_Roll_No2 = new Label("Roll No.");
	public TextField txt_Roll_No2 = new TextField();
	private Button btn_delete = new Button("Delete");

	public int yaxis = 220;

	private Label lbl_PdfFileName = new Label("Report Name");
	public TextField txt_pdffileName = new TextField();
	private Button btn_generatePdf = new Button("Generate");
	private Button btn_openFile = new Button("Open Report");
	public int pdf1y=300;
	public int pdf2y=350;


	public UserInterface(Pane theRoot, Stage Stage) {

		setupLabelUI(lbl_fileName, "Arial", 24, 100, Pos.CENTER, 50, loadfile1y);
		setupTextUI(txt_fileName, "Arial", 24, 300, Pos.CENTER, 200, loadfile1y, false);
		setupButtonUI(btn_browse, "Arial", 24, 100, Pos.CENTER, 500, loadfile1y);
		setupButtonUI(btn_loadData, "Arial", 24, 200, Pos.CENTER, 200, loadfile2y);

		btn_browse.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				try {
					FileChooser FChooser = new FileChooser();
					File selectedFile = FChooser.showOpenDialog(Stage);
					String fileName = selectedFile.getName().toString();
					if (fileName.toLowerCase().endsWith(".xlsx") && !fileName.toLowerCase().startsWith("~$")) {
						txt_fileName.setText(selectedFile.getAbsolutePath());
					} else {
						txt_fileName.setText("");
					}
				}
				catch(Exception e) {
					Alert alert = new Alert(AlertType.ERROR, "File Not Selected",ButtonType.OK);
					alert.showAndWait();
					txt_fileName.setText("Not Selected");
				}
			}
		});


		btn_loadData.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				if(txt_fileName.getText().equals("Not Selected") || txt_fileName.getText().equals("")) {
					Alert alert = new Alert(AlertType.INFORMATION, "Please select an appropriate excel file",ButtonType.OK);
					alert.showAndWait();
				}
				else {
					importDataFromExcelToDatabase();
				}
			}
		});


		setupButtonUI(btn_addData, "Arial", 24, 100, Pos.CENTER, 200, yaxis);
		btn_addData.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				Stage theStage = new Stage();
				theStage.setTitle("Add Student");
				Pane theRoot = new Pane();

				int lbl_x = 50;
				int lbl_x2 = 220;
				setupLabelUI(lbl_Reg_No, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 40);
				setupLabelUI(lbl_Roll_No, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 100);
				setupLabelUI(lbl_Name, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 160);
				setupLabelUI(lbl_Father_Name, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 220);
				setupLabelUI(lbl_Mother_Name, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 280);
				setupLabelUI(lbl_Course, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 340);
				setupLabelUI(lbl_Semester, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 400);
				setupLabelUI(lbl_Year, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 460);

				setupTextUI(txt_Reg_No, "Arial", 24, 300, Pos.CENTER, lbl_x2, 40, true);
				setupTextUI(txt_Roll_No, "Arial", 24, 300, Pos.CENTER, lbl_x2, 100, true);
				setupTextUI(txt_Name, "Arial", 24, 300, Pos.CENTER, lbl_x2, 160, true);
				setupTextUI(txt_Father_Name, "Arial", 24, 300, Pos.CENTER, lbl_x2, 220, true);
				setupTextUI(txt_Mother_Name, "Arial", 24, 300, Pos.CENTER, lbl_x2, 280, true);
				setupTextUI(txt_Course, "Arial", 24, 300, Pos.CENTER, lbl_x2, 340, true);
				setupTextUI(txt_Semester, "Arial", 24, 300, Pos.CENTER, lbl_x2, 400, true);
				setupTextUI(txt_Year, "Arial", 24, 300, Pos.CENTER, lbl_x2, 460, true);

				setupButtonUI(btn_add, "Arial", 24, 200, Pos.CENTER, 200, 520);

				btn_add.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							addStudent();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				Scene secondScene = new Scene(theRoot, 550, 600);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(btn_add,txt_Reg_No,txt_Roll_No,txt_Name,txt_Father_Name,txt_Mother_Name,txt_Course,txt_Semester,txt_Year,lbl_Reg_No,lbl_Roll_No,lbl_Name,lbl_Father_Name,lbl_Mother_Name,lbl_Course,lbl_Semester,lbl_Year);
				theStage.show();
			}
		});


		setupButtonUI(btn_modifyData, "Arial", 24, 100, Pos.CENTER, 320, yaxis);
		btn_modifyData.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				Stage theStage = new Stage();
				theStage.setTitle("Select Student");
				Pane theRoot = new Pane();

				int lbl_x = 50;
				int lbl_x2 = 220;
				setupLabelUI(lbl_Roll_No1, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 100);
				setupTextUI(txt_Roll_No1, "Arial", 24, 300, Pos.CENTER, lbl_x2, 100, true);

				setupButtonUI(btn_select, "Arial", 24, 200, Pos.CENTER, 200, 200);

				btn_select.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							selectStudent();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				Scene secondScene = new Scene(theRoot, 550, 300);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(btn_select,txt_Roll_No1,lbl_Roll_No1);
				theStage.show();
			}
		});


		setupButtonUI(btn_deleteData, "Arial", 24, 100, Pos.CENTER, 440, yaxis);
		btn_deleteData.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				Stage theStage = new Stage();
				theStage.setTitle("Delete Student");
				Pane theRoot = new Pane();

				int lbl_x = 50;
				int lbl_x2 = 220;
				setupLabelUI(lbl_Roll_No2, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 100);
				setupTextUI(txt_Roll_No2, "Arial", 24, 300, Pos.CENTER, lbl_x2, 100, true);

				setupButtonUI(btn_delete, "Arial", 24, 200, Pos.CENTER, 200, 200);

				btn_delete.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							deleteStudent();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				Scene secondScene = new Scene(theRoot, 550, 300);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(btn_delete,txt_Roll_No2,lbl_Roll_No2);
				theStage.show();
			}
		});


		setupLabelUI(lbl_PdfFileName, "Arial", 24, 100, Pos.CENTER, 50, pdf1y);
		setupTextUI(txt_pdffileName, "Arial", 24, 300, Pos.CENTER, 200, pdf1y, true);
		setupButtonUI(btn_generatePdf, "Arial", 22, 100, Pos.CENTER, 500, pdf1y);
		setupButtonUI(btn_openFile, "Arial", 24, 200, Pos.CENTER, 200, pdf2y);

		btn_generatePdf.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				try {
					if(txt_pdffileName.getText().equals("")) {
						Alert alert = new Alert(AlertType.INFORMATION, "Please enter a pdf file name",ButtonType.OK);
						alert.showAndWait();
					}
					else {
						createPdf();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});


		btn_openFile.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				openFile();

			}
		});




		theRoot.getChildren().addAll(btn_modifyData,btn_deleteData,btn_addData,lbl_fileName,btn_browse,txt_fileName,btn_generatePdf,btn_loadData,txt_pdffileName,btn_openFile,lbl_PdfFileName);
	}


	/*******
	 * This public methods invokes the methods of mainline class and generate a
	 * specific error message when the user enters the value of operand1
	 *
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}


	/*
	 * Insert data from excel to the database table
	 */

	public void importDataFromExcelToDatabase() {

		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://"+LOCALHOST+"/"+DATABASE_NAME+"?user="+USER+"&password="+PASSWORD);
			con.setAutoCommit(true);
			PreparedStatement pstm = null ;
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(txt_fileName.getText().toString());
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row;
			for(int i=1; i<=sheet.getLastRowNum(); i++){
				row = sheet.getRow(i);
				String regno = String.valueOf(row.getCell(0).getNumericCellValue());
				String rollno = String.valueOf(row.getCell(1).getNumericCellValue());
				String name = row.getCell(2).getStringCellValue();
				String fathername = row.getCell(3).getStringCellValue();
				String mothername = row.getCell(4).getStringCellValue();
				String course = row.getCell(5).getStringCellValue();
				String semester = String.valueOf(row.getCell(6).getNumericCellValue());
				String year = String.valueOf(row.getCell(7).getNumericCellValue());
				String sql = "INSERT INTO "+TABLE1_NAME+" VALUES('"+regno+"','"+rollno+"','"+name+"','"+fathername+"','"+mothername+"','"+course+"','"+semester+"','"+year+"')";

				pstm = (PreparedStatement) con.prepareStatement(sql);
				pstm.execute();
			}
			pstm.close();
			con.close();
			System.out.println("Success import excel to mysql table");
			Alert alert = new Alert(AlertType.CONFIRMATION, "Data is successfully inserted",ButtonType.OK);
			alert.showAndWait();
		}catch(Exception e){
			Alert alert = new Alert(AlertType.ERROR, "Data not inserted successfully and problem is\n"+e,ButtonType.OK);
			alert.showAndWait();
			System.out.println(e);
		}
	}

	/*
	 * Create a pdf according to the data
	 */

	public void createPdf() throws Exception {

		try {
			Document document=new Document();
			PdfWriter.getInstance(document,new FileOutputStream(txt_pdffileName.getText().toString()+".pdf"));
			document.open();

			PdfPTable table=new PdfPTable(8);
			table.addCell("Reg_No");			
			table.addCell("Roll_No");
			table.addCell("Name");
			table.addCell("Father_Name");
			table.addCell("Mother_Name");
			table.addCell("Course");
			table.addCell("Semester");
			table.addCell("Year");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://"+LOCALHOST+"/"+DATABASE_NAME+"?user="+USER+"&password="+PASSWORD);			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("Select * from "+TABLE1_NAME);  
			while(rs.next()){
				table.addCell(rs.getString("Reg_No"));		
				table.addCell(rs.getString("Roll_No"));
				table.addCell(rs.getString("Name"));
				table.addCell(rs.getString("Father_Name"));
				table.addCell(rs.getString("Mother_Name"));
				table.addCell(rs.getString("Course"));
				table.addCell(rs.getString("Semester"));
				table.addCell(rs.getString("Year"));
			}
			document.add(table);
			document.close();
			Alert alert = new Alert(AlertType.CONFIRMATION, "File is created successfully",ButtonType.OK);
			alert.showAndWait();
		}
		catch(Exception e) {
			Alert alert = new Alert(AlertType.ERROR, "File is not created",ButtonType.OK);
			alert.showAndWait();
		}
	}

	public void openFile() {

		try {
			File pdfFile = new File(txt_pdffileName.getText().toString()+".pdf");
			Desktop.getDesktop().open(pdfFile);
		} catch (Exception ex) {
			Alert alert = new Alert(AlertType.ERROR, "Valid file name is not enter",ButtonType.OK);
			alert.showAndWait();
		}
	}

	public void addStudent() {
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://"+LOCALHOST+"/"+DATABASE_NAME+"?user="+USER+"&password="+PASSWORD);
			con.setAutoCommit(true);
			PreparedStatement pstm = null ;

			String regno=txt_Reg_No.getText().toString();
			String rollno=txt_Roll_No.getText().toString();
			String name=txt_Name.getText().toString();
			String fathername=txt_Father_Name.getText().toString();
			String mothername=txt_Mother_Name.getText().toString();
			String course=txt_Course.getText().toString();
			String semester=txt_Semester.getText().toString();
			String year=txt_Year.getText().toString();
			String sql = "INSERT INTO "+TABLE1_NAME+" VALUES('"+regno+"','"+rollno+"','"+name+"','"+fathername+"','"+mothername+"','"+course+"','"+semester+"','"+year+"')";
			pstm = (PreparedStatement) con.prepareStatement(sql);
			pstm.execute();

			pstm.close();
			con.close();
			Alert alert = new Alert(AlertType.CONFIRMATION, "Data is successfully inserted",ButtonType.OK);
			alert.showAndWait();
		}catch(Exception e){
			Alert alert = new Alert(AlertType.ERROR, "Data not inserted successfully and problem is\n"+e,ButtonType.OK);
			alert.showAndWait();
			System.out.println(e);
		}
	}

	public void deleteStudent() {
		String rollno = txt_Roll_No2.getText().toString();
		if(rollno.equals("")) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please enter valid rollno",ButtonType.OK);
			alert.showAndWait();
		}
		else {
			try{
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://"+LOCALHOST+"/"+DATABASE_NAME+"?user="+USER+"&password="+PASSWORD);
				con.setAutoCommit(true);
				PreparedStatement ps = con.prepareStatement("delete from "+TABLE1_NAME+" where Roll_No=?");
				ps.setString(1,rollno);
				int a =ps.executeUpdate();
				if (a==1) {
					Alert alert = new Alert(AlertType.CONFIRMATION, "Record Deleted Successfully",ButtonType.OK);
					alert.showAndWait();
				}
				else {
					Alert alert = new Alert(AlertType.CONFIRMATION, "Record not found",ButtonType.OK);
					alert.showAndWait();
				}
			}
			catch(Exception e){
				Alert alert = new Alert(AlertType.CONFIRMATION, "Record not found",ButtonType.OK);
				alert.showAndWait();
			}
		}
	}

	public void selectStudent() {
		String rollno = txt_Roll_No1.getText().toString();
		if(rollno.equals("")) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please enter valid rollno",ButtonType.OK);
			alert.showAndWait();
		}
		else {

			try {
				Stage theStage = new Stage();
				theStage.setTitle("Add Student");
				Pane theRoot = new Pane();

				int lbl_x = 50;
				int lbl_x2 = 220;
				setupLabelUI(lbl_Reg_No, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 40);
				setupLabelUI(lbl_Roll_No, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 100);
				setupLabelUI(lbl_Name, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 160);
				setupLabelUI(lbl_Father_Name, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 220);
				setupLabelUI(lbl_Mother_Name, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 280);
				setupLabelUI(lbl_Course, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 340);
				setupLabelUI(lbl_Semester, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 400);
				setupLabelUI(lbl_Year, "Arial", 22, 50, Pos.BASELINE_LEFT, lbl_x, 460);

				setupTextUI(txt_Reg_No, "Arial", 24, 300, Pos.CENTER, lbl_x2, 40, false);
				setupTextUI(txt_Roll_No, "Arial", 24, 300, Pos.CENTER, lbl_x2, 100, false);
				setupTextUI(txt_Name, "Arial", 24, 300, Pos.CENTER, lbl_x2, 160, true);
				setupTextUI(txt_Father_Name, "Arial", 24, 300, Pos.CENTER, lbl_x2, 220, true);
				setupTextUI(txt_Mother_Name, "Arial", 24, 300, Pos.CENTER, lbl_x2, 280, true);
				setupTextUI(txt_Course, "Arial", 24, 300, Pos.CENTER, lbl_x2, 340, true);
				setupTextUI(txt_Semester, "Arial", 24, 300, Pos.CENTER, lbl_x2, 400, true);
				setupTextUI(txt_Year, "Arial", 24, 300, Pos.CENTER, lbl_x2, 460, true);



				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://"+LOCALHOST+"/"+DATABASE_NAME+"?user="+USER+"&password="+PASSWORD);
				PreparedStatement ps = con.prepareStatement("select * from "+TABLE1_NAME+" where Roll_No='"+rollno+"'");
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
					String regnno = rs.getString(1);
					String rollno2 = rs.getString(2);
					String name = rs.getString(3);
					String fathername = rs.getString(4);
					String mothername = rs.getString(5);
					String course=rs.getString(6);
					String semester=rs.getString(7);
					String year=rs.getString(8);
					txt_Reg_No.setText(regnno);
					txt_Roll_No.setText(rollno2);
					txt_Name.setText(name);
					txt_Father_Name.setText(fathername);
					txt_Mother_Name.setText(mothername);
					txt_Course.setText(course);
					txt_Semester.setText(semester);
					txt_Year.setText(year);


				}

				setupButtonUI(btn_update, "Arial", 24, 200, Pos.CENTER, 200, 520);

				btn_update.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							updateStudent();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				Scene secondScene = new Scene(theRoot, 550, 600);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(btn_update,txt_Reg_No,txt_Roll_No,txt_Name,txt_Father_Name,txt_Mother_Name,txt_Course,txt_Semester,txt_Year,lbl_Reg_No,lbl_Roll_No,lbl_Name,lbl_Father_Name,lbl_Mother_Name,lbl_Course,lbl_Semester,lbl_Year);
				theStage.show();
			}
			catch (Exception e) {
				Alert alert = new Alert(AlertType.CONFIRMATION, "Record not found",ButtonType.OK);
				alert.showAndWait();
			}
		}
	}

	public void updateStudent() {

		String rollno=txt_Roll_No.getText().toString();
		String name=txt_Name.getText().toString();
		String fathername=txt_Father_Name.getText().toString();
		String mothername=txt_Mother_Name.getText().toString();
		String course=txt_Course.getText().toString();
		String semester=txt_Semester.getText().toString();
		String year=txt_Year.getText().toString();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://"+LOCALHOST+"/"+DATABASE_NAME+"?user="+USER+"&password="+PASSWORD);
			PreparedStatement ps = con.prepareStatement("update "+TABLE1_NAME+" set Name = ?,Father_Name=?,Mother_Name=?,Course=?,Semester=?,Year=? where Roll_No=?");
			ps.setString(1,name);
			ps.setString(2,fathername);
			ps.setString(3,mothername);
			ps.setString(4,course);
			ps.setString(5,semester);
			ps.setString(6,year);
			ps.setString(7,rollno);
			int a =ps.executeUpdate();
			if (a==1) {
				Alert alert = new Alert(AlertType.CONFIRMATION, "Record Updated Successfully",ButtonType.OK);
				alert.showAndWait();
			}
			else {
				Alert alert = new Alert(AlertType.CONFIRMATION, "Record not found",ButtonType.OK);
				alert.showAndWait();
			}
		}
		catch(Exception e){
			Alert alert = new Alert(AlertType.CONFIRMATION, "Record not found",ButtonType.OK);
			alert.showAndWait();
		}
	}

}
