package WK12SH2;

/**
 * 
 * Data Manipulation Language 
 * 
 * 3. Delete a column command
 * 
 * @author Shivam 
 */

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.util.Bytes;

public class B3Delete {

   public static void main(String[] args) throws IOException {

      Configuration conf = HBaseConfiguration.create();
      HTable table=new HTable(conf, Bytes.toBytes("vehicles"));
      Delete delCmd=new Delete(Bytes.toBytes("1"));
      delCmd.deleteColumn(Bytes.toBytes("car"), Bytes.toBytes("CarCompany"));
      table.delete(delCmd);
      table.close();
      System.out.println("Delete Command Successful");
   }
}