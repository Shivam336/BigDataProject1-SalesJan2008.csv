package WK12SH2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.util.Bytes;

public class B7Truncate {
	
	public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
		
		Configuration conf=new Configuration();
		HBaseAdmin admin = new HBaseAdmin(conf);
		admin.disableTable(Bytes.toBytes("vehicles"));
		//TableName table=TableName(Bytes.toBytes("vehicles"));
		admin.truncateTable(table, true);
		admin.truncateTable(Bytes.toBytes("vehicles"), false);
		
		
	}

}
